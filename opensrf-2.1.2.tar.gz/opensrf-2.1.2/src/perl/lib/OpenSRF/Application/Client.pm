package OpenSRF::App::Client;
use base 'OpenSRF::Application';
use OpenSRF::Utils::Logger qw/:level/;


1;
