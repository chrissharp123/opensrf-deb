package org.opensrf.util;
/**
 * Used to indicate JSON parsing errors
 */
public class JSONException extends Exception {
    public JSONException(String s) {
        super(s);
    }
}
