package org.opensrf;

/**
 * Models an OpenSRF server session.
 */
public class ServerSession extends Session {
}

