dojo.provide("opensrf.tests.module");
dojo.require("DojoSRF");

try{
	dojo.require("opensrf.tests.testJSON_v1");
}catch(e){
	doh.debug(e);
}
