#ifndef __OPENSRF_CHECK_H__
#define __OPENSRF_CHECK_H__

#endif /* __OPENSRF_CHECK_H__ */
