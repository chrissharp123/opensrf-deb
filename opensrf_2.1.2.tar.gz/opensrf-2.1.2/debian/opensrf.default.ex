# Defaults for opensrf initscript
# sourced by /etc/init.d/opensrf
# installed at /etc/default/opensrf by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
